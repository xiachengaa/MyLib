TextViewPlaceholder
===================

<u>自定义TextView,可根据内容来 是否显示 Placeholder,可自定义Placeholder的文字颜色、大小.<u><br>
<img src="http://7xj1v1.com1.z0.glb.clouddn.com/textView.gif" />
