//
//  TWPhotoCollectionViewCell.h
//  InstagramPhotoPicker
//
//  Created by Emar on 12/4/14.
//  Copyright (c) 2014 wenzhaot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TWPhotoCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) UIImageView *imageView;
@end
